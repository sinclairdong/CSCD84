g++ -c -g -O3 -fPIC AI_search.c
g++ -g *.o -lm -lglut -lGL -lGLU -lX11 -o AI_search

